def run(load, main):
    load(None)
    main()
